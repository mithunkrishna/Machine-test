<?php  if(session('success_msg')!=''){ ?>
<div class="alert alert-success alert-dismissible">
	<?php echo session('success_msg');?>
</div>
<?php session()->remove('success_msg'); } ?>
<?php  if(session('error_msg')!=''){ ?>
<div class="alert alert-danger alert-dismissible">
	<?php echo session('error_msg');?>
</div>
<?php session()->remove('error_msg'); } ?>
<?php  if(validation_errors()){ ?>
	<div class="alert alert-danger alert-dismissible">
	<?php echo validation_errors();?>
</div>
<?php }  ?>
