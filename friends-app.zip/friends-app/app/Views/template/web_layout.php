<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo (@$page_title)?$page_title:'Friends App'?></title>
    <!-- plugins:css -->
    <link rel="stylesheet"
        href="<?php echo base_url('public/assets/assets/vendors/mdi/css/materialdesignicons.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('public/assets/assets/vendors/css/vendor.bundle.base.css')?>">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo base_url('public/assets/assets/css/style.css')?>">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo base_url('public/assets/assets/images/favicon.ico')?>" />
    <link rel="canonical" href="<?php echo current_url(); ?>">
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo" href="<?php echo base_url('friend-suggestions');?>"><img
                        src="<?php echo base_url('public/assets/assets/images/logo.svg')?>" alt="logo" /></a>
                <a class="navbar-brand brand-logo-mini" href="<?php echo base_url('friend-suggestions');?>"><img
                        src="<?php echo base_url('public/assets/assets/images/logo-mini.svg')?>" alt="logo" /></a>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-stretch">
                <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                    <span class="mdi mdi-menu"></span>
                </button>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <div class="nav-profile-img">
                                <?php
                                $udata = @$umodel->getuser_data(session()->get('user_id'));
                                $frequest_cnt = @$umodel->getuser_frequest(session()->get('user_id'));
                                ?>
                                <img src="<?php echo (file_exists(base_url('public/uploads/profile/small/'.$udata[0]->profile_img)))?base_url('public/uploads/profile/small/'.$udata[0]->profile_img):base_url('public/uploads/profile/'.$udata[0]->profile_img)?>"
                                    alt="<?php echo $udata[0]->name?>">
                                <span class="availability-status online"></span>
                            </div>
                            <div class="nav-profile-text">
                                <p class="mb-1 text-black"><?php echo $udata[0]->name?></p>
                            </div>
                        </a>
                        <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                            <a class="dropdown-item" href="<?php echo base_url('view-profile')?>">
                                <i class="mdi mdi-cached me-2 text-success"></i> View Profile </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo base_url('logout')?>">
                                <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
                        </div>
                    </li>
                    <li class="nav-item d-none d-lg-block full-screen-link">
                        <a class="nav-link">
                            <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#"
                            data-bs-toggle="dropdown">
                            <i class="mdi mdi-bell-outline"></i>
                            <span class="count-symbol bg-danger"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list"
                            aria-labelledby="notificationDropdown">
                            <h6 class="p-3 mb-0">Notifications</h6>

                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item preview-item">
                                <div class="preview-thumbnail">
                                    <div class="preview-icon bg-warning">
                                        <i class="mdi mdi-account"></i>
                                    </div>
                                </div>
                                <div
                                    class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                                    <p class="text-gray ellipsis mb-0"> (<?php echo $frequest_cnt?>) Friend Request </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-logout d-none d-lg-block">
                        <a class="nav-link" href="<?php echo base_url('logout')?>">
                            <i class="mdi mdi-power"></i>
                        </a>
                    </li>
                    <li class="nav-item nav-settings d-none d-lg-block">
                        <a class="nav-link" href="#">
                            <i class="mdi mdi-format-line-spacing"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item nav-profile">
                        <a href="#" class="nav-link">
                            <div class="nav-profile-image">
                                <img src="<?php echo (file_exists(base_url('public/uploads/profile/small/'.$udata[0]->profile_img)))?base_url('public/uploads/profile/small/'.$udata[0]->profile_img):base_url('public/uploads/profile/'.$udata[0]->profile_img)?>"
                                    alt="<?php echo $udata[0]->name?>">
                                <span class="login-status online"></span>
                                <!--change to offline or busy as needed-->
                            </div>
                            <div class="nav-profile-text d-flex flex-column">
                                <span class="font-weight-bold mb-2"><?php echo $udata[0]->name?></span>
                                <span class="text-secondary text-small"><?php echo $udata[0]->email?></span>
                            </div>
                            <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo base_url('friend-suggestions');?>">
                            <span class="menu-title">Friend Suggestions</span>
                            <i class="mdi mdi-account-convert menu-icon"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo base_url('friend-list');?>">
                            <span class="menu-title">Friend List</span>
                            <i class="mdi mdi-account-plus menu-icon"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo base_url('view-profile')?>">
                            <span class="menu-title">View Profile</span>
                            <i class="mdi mdi-account menu-icon"></i>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="main-panel">
                <?php $this->renderSection('content');?>
            </div>
        </div>
    </div>
    <!-- container-scroller -->
    <script src="<?php echo base_url('public/assets/assets/vendors/js/vendor.bundle.base.js')?>"></script>
    <script src="<?php echo base_url('public/assets/assets/js/misc.js')?>"></script>
    <!-- End custom js for this page -->
    <?php $this->renderSection('jscript');?>
</body>

</html>