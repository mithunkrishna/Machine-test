<?php
$this->extend('template/web_layout');
$this->section('content');?>
<!-- partial -->
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title"> Edit User Profile </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit User Profile</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Profile</h4>
                    <?php echo view('template\error_msg');?>
                    <?php echo form_open_multipart($editaction, ['id' => 'cpassForm']);?>
                    <div class="form-group row">
                        <label for="name" class="col-sm-3 col-form-label">New Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name="new_pass" id="new_pass"
                                placeholder="New Password *" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Confirm New Password</label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name="cnew_pass" id="cnew_pass"
                                placeholder="Confirm New Password *" required="required">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    <button class="btn btn-light"
                        onClick="document.location.href='<?php echo base_url('view-profile')?>'">Cancel</button>
                    <?php echo form_close();?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- page-body-wrapper ends -->
<?php $this->endSection();?>
<?php  $this->section('jscript');?>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js" type="text/javascript">
</script>
<script>
jQuery('#cpassForm').validate({
    rules: {
        new_pass: {
            minlength: 5
        },
        cnew_pass: {
            minlength: 5,
            equalTo: "#new_pass"
        }
    }
});
</script>
<?php $this->endSection();?>