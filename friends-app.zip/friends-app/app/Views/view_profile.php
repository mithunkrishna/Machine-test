<?php
$this->extend('template/web_layout');
$this->section('content');?>
<!-- partial -->
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> User Profile </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                </ol>
            </nav>
        </div>
        <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <?php echo view('template\error_msg');?>  
                  <p><img src="<?php echo (file_exists(base_url('public/uploads/profile/'.$udata[0]->profile_img)))?base_url('public/uploads/profile/small/'.$udata[0]->profile_img):base_url('public/uploads/profile/'.$udata[0]->profile_img)?>"
                  alt="<?php echo $udata[0]->name?>" width="100"></p>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Name</label>
                        <div class="col-sm-9 m-auto"><?php echo $udata[0]->name?></div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9 m-auto"><?php echo $udata[0]->email?></div>
                      </div>
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Gender</label>
                        <div class="col-sm-9 m-auto"><?php echo ($udata[0]->gender == 1)?"Male":"Female"?></div>
                      </div>
                      <a href="<?php echo base_url('edit-profile');?>"><button class="btn btn-gradient-primary me-2"><i class="mdi mdi-pencil"></i> Edit Profile</button></a>
                      <a href="<?php echo base_url('change-password');?>"><button class="btn btn-gradient-primary me-2"><i class="mdi mdi-lock-outline"></i> Change Password</button></a>
                  </div>
                </div>
              </div>
        </div>
    </div>
<!-- page-body-wrapper ends -->
<?php $this->endSection();?>