<?php
$this->extend('template/web_layout');
$this->section('content');?>
<!-- partial -->
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title"> Friend Suggestions </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Friend Suggestions</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">List Friend Suggestions</h4>
                    <?php if (@$pager->getPageCount() > 1){ echo @$pager->makeLinks($page,$perPage, $total,'user_pagination');} ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th> Sl No. </th>
                                <th> User </th>
                                <th> Name </th>
                                <th> Email </th>
                                <th> Gender </th>
                                <th> Action </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                 if(!empty($result)){
                                foreach($result as $key => $suggestions){?>
                            <tr>
                                <td> <?php echo ++$key?> </td>
                                <td class="py-1">
                                    <img src="<?php echo (file_exists(base_url('public/uploads/profile/small/'.$suggestions->profile_img)))?base_url('public/uploads/profile/small/'.$suggestions->profile_img):base_url('public/uploads/profile/'.$suggestions->profile_img)?>"
                                        alt="<?php echo $suggestions->name?>" />
                                </td>
                                <td> <?php echo $suggestions->name?> </td>
                                <td> <?php echo $suggestions->email?> </td>
                                <td> <?php echo ($suggestions->gender == 1)?"Male":"Female"?> </td>
                                <td> <button type="button" class="btn btn-gradient-info btn-rounded btn-fw addFrnd"
                                        data-id="<?php echo $suggestions->id?>">Add friend</button> </td>
                                <td> <?php echo date('F d, Y',strtotime($suggestions->created_at));?></td>
                            </tr>
                            <?php } }else{?>
                            <tr>
                                <td colspan="6"> There is no data</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- page-body-wrapper ends -->
<?php $this->endSection();?>
<?php  $this->section('jscript');?>
<script>
$(document).ready(function() {
    $('.addFrnd').on("click", function() {
        // CSRF Hash
        var csrfName = '<?= csrf_token() ?>';
        var csrfHash = '<?= csrf_hash() ?>';
        var to_id = $(this).data("id");
        if (confirm('Do You Want to Send Request')) {
            $.ajax({
                type: "POST",
                data: {
                    'to_id': to_id,
                    [csrfName]: csrfHash
                },
                url: "<?php echo base_url('add-friend') ?>",
                success: function(d) {
                    if (d)
                        alert("Sucessfully send request");
                    else
                        alert("Ooops! something went wrong please try again");
                    location.reload();
                }
            });
        }
    })
})
</script>
<?php $this->endSection();?>