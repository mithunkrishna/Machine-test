<?php
$this->extend('template/web_layout');
$this->section('content');?>
<!-- partial -->
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title"> Edit User Profile </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit User Profile</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Profile</h4>
                    <?php echo view('template\error_msg');?>
                    <?php echo form_open_multipart($editaction, ['id' => 'editForm']);?>
                    <div class="form-group row">
                        <label for="name" class="col-sm-3 col-form-label">Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="name" placeholder="Name *"
                                value="<?php echo $udata[0]->name?>" required="required">
                                <input type="hidden"  name="id" value="<?php echo $udata[0]->id?>" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" name="email" placeholder="Email *"
                                value="<?php echo $udata[0]->email?>" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Gender</label>
                            <div class="col-sm-4">
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="gender" value="1"
                                            <?php echo ($udata[0]->gender == 1)?"checked":""?>> Male <i
                                            class="input-helper"></i></label>
                                </div>
                            </div>
                            <div class="col-sm-5">
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="radio" class="form-check-input" name="gender" value="2"
                                            <?php echo ($udata[0]->gender == 2)?"checked":""?>> Female <i
                                            class="input-helper"></i></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label>Profile image upload <img
                                src="<?php echo (file_exists(base_url('public/uploads/profile/'.$udata[0]->profile_img)))?base_url('public/uploads/profile/small/'.$udata[0]->profile_img):base_url('public/uploads/profile/'.$udata[0]->profile_img)?>"
                                alt="<?php echo $udata[0]->name?>" width="100"></label>
                        <input type="file" name="image" accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-gradient-primary me-2">Update</button>
                    <button class="btn btn-light"
                        onClick="document.location.href='<?php echo base_url('view-profile')?>'">Cancel</button>
                    <?php echo form_close();?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- page-body-wrapper ends -->
<?php $this->endSection();?>