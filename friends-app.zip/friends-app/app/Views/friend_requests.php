<?php
$this->extend('template/web_layout');
$this->section('content');?>
<!-- partial -->
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title"> Friends List
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Friends List
                </li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Friends List
                    </h4>
                    <?php if (@$pager->getPageCount() > 1){ echo @$pager->makeLinks($page,$perPage, $total,'custom_pagination');} ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th> Sl No. </th>
                                <th> User </th>
                                <th> Name </th>
                                <th> Email </th>
                                <th> Gender </th>
                                <th> </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if(!empty($result)){
                            foreach($result as $key => $frequest){?>
                            <tr>
                                <td> <?php echo ++$key?> </td>
                                <td class="py-1">
                                    <img src="<?php echo (file_exists(base_url('public/uploads/profile/small/'.$frequest->profile_img)))?base_url('public/uploads/profile/small/'.$frequest->profile_img):base_url('public/uploads/profile/'.$frequest->profile_img)?>"
                                        alt="<?php echo $frequest->name?>" />
                                </td>
                                <td> <?php echo $frequest->name?> </td>
                                <td> <?php echo $frequest->email?> </td>
                                <td> <?php echo ($frequest->gender == 1)?"Male":"Female"?> </td>
                                <td> <?php echo date('F d, Y',strtotime($frequest->created_at));?></td>
                            </tr>
                            <?php } }else{?>
                                <tr>  <td colspan="6"> There is no data</td></tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- page-body-wrapper ends -->
<?php $this->endSection();?>