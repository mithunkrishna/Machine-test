<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->set404Override('\App\Controllers\Home::pageNotFound');
$routes->group('', ['namespace' => 'App\Controllers'], function ($routes) {
  $routes->add('/', 'Home::index');
  $routes->add('index', 'Home::index'); 
  $routes->add('user-registraion', 'Home::user_registraion');
  $routes->add('check-login', 'Home::check_login');
  $routes->add('friend-suggestions', 'Home::user_lists');
  $routes->add('add-friend', 'Home::add_friend');
  $routes->add('friend-list', 'Home::friend_requests');
  $routes->add('view-profile', 'Home::view_profile');
  $routes->add('edit-profile', 'Home::edit_profile');
  $routes->add('update-profile', 'Home::update_profile');
  $routes->add('change-password', 'Home::change_password');
  $routes->add('submit-new-password', 'Home::submit_new_password');
  $routes->add('logout', 'Home::logout');
});