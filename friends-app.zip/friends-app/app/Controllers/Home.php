<?php

namespace App\Controllers;
use App\Models\Usermodel;
use App\Models\Addfriendmodel;
class Home extends BaseController
{

    public function __construct()
    {
       
        $this->data['umodel']   = $this->usermodel        = new Usermodel();
        $this->addfriendmodel   = new Addfriendmodel();
        $this->data['uri']      = \Config\Services::uri();
    }
    public function index()
    {
        $data['loginaction'] = 'check-login';
        $data['regaction']   = 'user-registraion';
		return view('login', $data);
    }
    function check_login()
    {
        $rule = [
            'email'   =>'required|valid_email',
            'pwd'     =>'required|min_length[5]'
        ];
        if(!$this->validate($rule)){
            session()->set('error_msg',$this->validator->listErrors());
            return redirect()->to('/');
        }
        else{
            $username = $this->request->getPost('email');
            $password = $this->request->getPost('pwd');
            // Perform authentication (you can customize this logic)
            $user = $this->usermodel->user_login($username, $password);
            if ($user) {
                 session()->set('user_id',$user[0]->id);   
                 return redirect()->to('friend-suggestions');
            } else {
                session()->set('error_msg','Invalid Credentials!');
                return redirect()->to('/');
            }
        }
    }
    function user_registraion()
    {
        $rule = [
            'name' 		=>'required',
            'email'     =>'required|valid_email|is_unique[ateam_users.email]',
            'gender'    =>'required',
            'paswd'     =>'required|min_length[5]',
        ];
        if(!$this->validate($rule)){
            session()->set('error_msg',$this->validator->listErrors());
            return redirect()->to('/');
        }
        else{
            $postData['name']          = $this->request->getPost('name');
            $postData['email']         = $this->request->getPost('email');  
            $postData['gender']        = $this->request->getPost('gender');
            $postData['password']      = md5($this->request->getPost('paswd')); 
            if(is_uploaded_file($_FILES['image']['tmp_name'])){
                $input = $this->validate([
                    'file' => [
                        'uploaded[image]',
                        'mime_in[image,image/jpg,image/jpeg,image/png,image/jpg,image/svg,image/svg+xml]',
                        'max_size[image,90000]',
                    ]
                ]);
                if(!$input)
                {
                    session()->set('error_msg','Invalid File Format or Maximum size Exceeds.');
                    return redirect()->to('/');
                }
                else{
                    $x_file = $this->request->getFile('image');
                    $x_file->move('public/uploads/profile/');
                    $ext = $x_file->getClientExtension();
                    if($ext!='svg'){
                    $image = \Config\Services::image()
                        ->withFile('public/uploads/profile/'. $x_file->getName())
                        ->resize(100, 71, true, 'height')
                        ->save('public/uploads/profile/small/'. $x_file->getName());
                    }
                    $postData['profile_img'] = $x_file->getName();
                }
            }
            $res  = $this->usermodel->insert($postData);
            if($res){
                session()->set('success_msg','Thank you for signing up, please login');
            }
            else  
                session()->set('error_msg','Please Try Again');
    
            return redirect()->to('/');
        }
    }
    public function user_lists()
    {
        
        $this->data['page']         = isset($_GET['page']) ? $_GET['page'] : 1;
        $this->data['perPage']      = 25;
        //$frequest_except            = $this->addfriendmodel->my_frequest_except(session()->get('user_id'));
        //$exceptAry = explode(",",$frequest_except[0]->from_id);
        $this->data['total']        = $this->usermodel->join('ateam_friends', 'ateam_users.id = ateam_friends.to_id AND from_id = '.session()->get('user_id'), 'left')->where(['ateam_users.id!='=>session()->get('user_id'),'ateam_friends.to_id'=> NULL])->countAllResults();
        $this->data['result']       = $this->usermodel->select('ateam_users.*')->join('ateam_friends', 'ateam_users.id = ateam_friends.to_id AND from_id = '.session()->get('user_id'), 'left')->where(['ateam_users.id!='=>session()->get('user_id'),'ateam_friends.to_id'=> NULL])->orderBy('ateam_users.id','DESC')->paginate($this->data['perPage']);
        //echo $this->usermodel->getLastQuery()->getQuery();
//exit;
        $this->data['pager']        = $this->usermodel->pager;
        return view('user_lists', $this->data);
    }
    public function add_friend()
    {
        $postData['to_id']      = $this->request->getPost('to_id');
        $postData['from_id']    = session()->get('user_id');
        if(count($postData) == 2){
        if($this->addfriendmodel->insert($postData))
            echo 1;
        }
        else
            echo 0;
    }
    public function friend_requests()
    {
        
        $this->data['page']         = isset($_GET['page']) ? $_GET['page'] : 1;
        $this->data['perPage']      = 25;
        $this->data['total']        = $this->addfriendmodel
                                    ->join('ateam_users', 'ateam_users.id = ateam_friends.to_id')
                                    ->where('ateam_friends.status !=',2)
                                    ->where('ateam_friends.to_id',session()->get('user_id'))->countAllResults();
        $this->data['result']       = $this->addfriendmodel
                                    ->select('u2.*,ateam_friends.id as fid,ateam_friends.created_at,ateam_friends.status')
                                    ->join('ateam_users u1', 'ateam_friends.to_id = u1.id')
                                    ->join('ateam_users u2', 'ateam_friends.from_id = u2.id')
                                    ->where('ateam_friends.status !=',2)
                                    ->where('ateam_friends.to_id',session()->get('user_id'))
                                    ->orderBy('ateam_friends.id','DESC')
                                    ->paginate($this->data['perPage']);
        $this->data['pager']        = $this->addfriendmodel->pager;
        return view('friend_requests', $this->data);
    }
    public function view_profile(){
        $this->data['udata'] = $this->usermodel->getuser_data(session()->get('user_id'));
        return view('view_profile', $this->data);
    }
    public function edit_profile(){
        $this->data['udata'] = $this->usermodel->getuser_data(session()->get('user_id'));
        $this->data['editaction'] = 'update-profile';
        return view('edit_profile', $this->data);
    }
    public function update_profile(){
        $rule = [
            'name' 		=>'required',
            'email'     =>'required|valid_email|is_unique[ateam_users.email,ateam_users.id,'.session()->get('user_id').']',
            'gender'    =>'required',
        ];
        if(!$this->validate($rule)){
            session()->set('error_msg',$this->validator->listErrors());
            return redirect()->to('edit-profile');
        }
        else{
            $postData['name']          = $this->request->getPost('name');
            $postData['email']         = $this->request->getPost('email');  
            $postData['gender']        = $this->request->getPost('gender');
            if(is_uploaded_file($_FILES['image']['tmp_name'])){
                $input = $this->validate([
                    'file' => [
                        'uploaded[image]',
                        'mime_in[image,image/jpg,image/jpeg,image/png,image/jpg,image/svg,image/svg+xml]',
                        'max_size[image,90000]',
                    ]
                ]);
                if(!$input)
                {
                    session()->set('error_msg','Invalid File Format or Maximum size Exceeds.');
                    return redirect()->to('/');
                }
                else{
                    $x_file = $this->request->getFile('image');
                    $x_file->move('public/uploads/profile/');
                    $ext = $x_file->getClientExtension();
                    if($ext!='svg'){
                    $image = \Config\Services::image()
                        ->withFile('public/uploads/profile/'. $x_file->getName())
                        ->resize(100, 71, true, 'height')
                        ->save('public/uploads/profile/small/'. $x_file->getName());
                    }
                    $postData['profile_img'] = $x_file->getName();
                }
            }
            $res  = $this->usermodel->update(session()->get('user_id'),$postData);
            if($res){
                session()->set('success_msg','Sucessfully Updated');
            }
            else  
                session()->set('error_msg','Please Try Again');
    
            return redirect()->to('view-profile');
        }
    }
    public function change_password(){
        $this->data['editaction'] = 'submit-new-password';
        return view('change_password', $this->data);
    }
    public function submit_new_password(){
        $rule = [
            'new_pass'     =>'required|min_length[5]',
            'cnew_pass'    =>'required|min_length[5]|matches[new_pass]',
        ];
        if(!$this->validate($rule)){
            session()->set('error_msg',$this->validator->listErrors());
            return redirect()->to('change-profile');
        }
        else{
            $postData['password']          = md5($this->request->getPost('new_pass'));
            $res  = $this->usermodel->update(session()->get('user_id'),$postData);
            if($res){
                session()->set('success_msg','Sucessfully Changed Password');
            }
            else  
                session()->set('error_msg','Please Try Again');
            return redirect()->to('view-profile');
        }
    }
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }
    public function pageNotFound(){
        $this->response->setStatusCode(404);
        $this->data['page_title']       = "404 Page";
        $this->data['meta_description'] = "404 Page";
        return view('404', $this->data);        
    }
}