<?php 
namespace App\Models;

use CodeIgniter\Model;

class Addfriendmodel extends Model
{
        protected $table = 'ateam_friends';   
        // Set your users table name
        protected $primaryKey = 'id';
        protected $returnType = 'object';
        // table fields
        protected $allowedFields = ['from_id', 'to_id', 'status','del_status'];
        public function my_frequest_except($u_id=''){
                $user = $this->select('GROUP_CONCAT(from_id SEPARATOR ",") as from_id', false);
                $user = $this->where('to_id', $u_id);
                return $user->find();
        }
}
