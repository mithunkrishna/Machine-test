<?php 
namespace App\Models;

use CodeIgniter\Model;

class Usermodel extends Model
{
        protected $table = 'ateam_users';   
        // Set your users table name
        protected $primaryKey = 'id';
        protected $returnType = 'object';
        // table fields
        protected $allowedFields = ['name', 'email', 'gender','password','profile_img'];
        public function user_login($username, $password)
        {
                // Retrieve user by username
                $user = $this->where('email', $username);
                $user = $this->where('password', md5($password));
                return $user->find();
        }
       public function getuser_data($uid=''){
                $user = $this->where('id', $uid);
                return $user->find();
       }
       public function getuser_frequest($uid=''){
        $query = $this->db->table('ateam_friends')
        ->select('ateam_friends.id')
        ->join('ateam_users', 'ateam_users.id = ateam_friends.to_id')
        ->where('ateam_friends.status',1)
        ->where('ateam_friends.to_id',$uid)
        ->countAllResults();
        return $query;
       }
       public function frequest_list($uid='', $perPage){
        $query = $this->db->table('ateam_friends')
        ->select('u2.*')
        ->join('ateam_users u1', 'ateam_friends.to_id = u1.to_id')
        ->join('ateam_users u2', 'ateam_friends.from_id = u2.to_id')
        ->where('ateam_friends.status',1)
        ->where('ateam_friends.to_id',$uid)
        ->orderBy('ateam_friends.id','DESC')
        ->paginate($perPage);
        return $query; 
       }
}
