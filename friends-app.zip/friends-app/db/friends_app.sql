-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 24, 2024 at 06:09 PM
-- Server version: 8.0.31
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `friends_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `ateam_friends`
--

DROP TABLE IF EXISTS `ateam_friends`;
CREATE TABLE IF NOT EXISTS `ateam_friends` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from_id` int DEFAULT NULL,
  `to_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int NOT NULL DEFAULT '1',
  `del_status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ateam_friends`
--

INSERT INTO `ateam_friends` (`id`, `from_id`, `to_id`, `created_at`, `status`, `del_status`) VALUES
(1, 3, 2, '2024-11-24 18:00:57', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ateam_users`
--

DROP TABLE IF EXISTS `ateam_users`;
CREATE TABLE IF NOT EXISTS `ateam_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => Male, 2 => Female',
  `profile_img` varchar(250) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ateam_users`
--

INSERT INTO `ateam_users` (`id`, `name`, `email`, `gender`, `profile_img`, `password`, `created_at`) VALUES
(1, 'Ram', 'ram@mail.com', 1, '24.jpg', 'd0970714757783e6cf17b26fb8e2298f', '2024-11-24 17:59:34'),
(2, 'Ravi', 'ravi@mail.com', 1, '15.jpg', 'd0970714757783e6cf17b26fb8e2298f', '2024-11-24 18:00:01'),
(3, 'anu', 'anu@mail.com', 2, 'thumb-1.png', 'd0970714757783e6cf17b26fb8e2298f', '2024-11-24 18:00:37');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
